from __future__ import annotations
import json, os, uuid
from pathlib import Path
import numpy as np, pandas as pd
from scipy.sparse import csr_matrix
from sklearn.decomposition import TruncatedSVD
from joblib import dump
from src.utils.common import ROOT, load_config, ensure_dirs, setup_logger, save_json, utc_now
LOG=setup_logger('training','logs/training.log')

def precision_recall_ndcg_at_k(test_items, ranked, k):
    top=ranked[:k]
    hits=[1 if i in test_items else 0 for i in top]
    precision=sum(hits)/k
    recall=sum(hits)/max(len(test_items),1)
    dcg=sum(h/np.log2(idx+2) for idx,h in enumerate(hits))
    ideal=sum(1/np.log2(idx+2) for idx in range(min(len(test_items),k)))
    ndcg=dcg/ideal if ideal else 0
    return precision, recall, ndcg

def main():
    cfg=load_config(); ensure_dirs('models','mlruns')
    events=pd.read_csv(ROOT/'data/prepared/user_item_events.csv')
    events['event_ts']=pd.to_datetime(events['event_ts'], utc=True)
    cutoff=events['event_ts'].max()-pd.Timedelta(days=cfg['model']['test_days'])
    train=events[events.event_ts < cutoff]; test=events[events.event_ts >= cutoff]
    mat=train.pivot_table(index='user_id', columns='item_id', values='interaction_strength', aggfunc='max', fill_value=0)
    users=list(mat.index); items=list(mat.columns)
    svd=TruncatedSVD(n_components=min(cfg['model']['n_components'], max(2, min(mat.shape)-1)), random_state=cfg['random_seed'])
    user_emb=svd.fit_transform(csr_matrix(mat.values)); item_emb=svd.components_.T
    scores=user_emb.dot(item_emb.T)
    k=cfg['model']['top_k']; metrics=[]
    user_to_idx={u:i for i,u in enumerate(users)}
    test_pos=test[test.interaction_strength>=3].groupby('user_id')['item_id'].apply(set).to_dict()
    train_seen=train.groupby('user_id')['item_id'].apply(set).to_dict()
    for u, truth in test_pos.items():
        if u not in user_to_idx: continue
        s=scores[user_to_idx[u]].copy()
        for seen in train_seen.get(u,set()):
            if seen in items: s[items.index(seen)] = -np.inf
        ranked=[items[i] for i in np.argsort(-s)]
        p,r,n=precision_recall_ndcg_at_k(truth, ranked, k)
        metrics.append({'user_id':u,'precision_at_k':p,'recall_at_k':r,'ndcg_at_k':n})
    mdf=pd.DataFrame(metrics)
    aggregate={
        'precision_at_10': float(mdf.precision_at_k.mean()) if len(mdf) else 0,
        'recall_at_10': float(mdf.recall_at_k.mean()) if len(mdf) else 0,
        'ndcg_at_10': float(mdf.ndcg_at_k.mean()) if len(mdf) else 0,
        'evaluated_users': int(len(mdf)), 'train_rows': int(len(train)), 'test_rows': int(len(test))
    }
    model={'users':users,'items':items,'user_embeddings':user_emb,'item_embeddings':item_emb,'explained_variance_ratio':svd.explained_variance_ratio_}
    dump(model, ROOT/'models/svd_recommender.joblib')
    mdf.to_csv(ROOT/'reports/model_user_metrics.csv', index=False)
    save_json(aggregate,'reports/model_performance.json')
    run_id=str(uuid.uuid4())[:8]; run_dir=ROOT/'mlruns'/run_id; run_dir.mkdir(parents=True, exist_ok=True)
    save_json({'run_id':run_id,'created_at':utc_now(),'parameters':cfg['model'],'metrics':aggregate,'artifacts':['models/svd_recommender.joblib','reports/model_performance.json']}, run_dir/'meta.json')
    LOG.info('Training complete metrics=%s run_id=%s', aggregate, run_id)
if __name__=='__main__': main()
